#include <stdio.h>
#include <unistd.h>

int main(void) {

#include "example0701.c"

{
#include "exercise0703.c"
}

   return 0;
}
