void *computethread(void *arg1);
