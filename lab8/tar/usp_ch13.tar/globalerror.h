int geterror(int *error);
int seterror(int error);
