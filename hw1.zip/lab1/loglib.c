#include <stdlib.h>
#include <string.h>
#include "log.h"
 
typedef struct list_struct {
     data_t item;
     struct list_struct *next;
} log_t;
 
static log_t *headptr = NULL;
static log_t *tailptr = NULL;
 
int addmsg(data_t data) {
  log_t *newnode;
	int nodesize;
		 
	nodesize = sizeof(log_t) + strlen(data.string) + 1;

	if ((newnode = (log_t *)(malloc(nodesize))) == NULL) return -1;
	
	newnode->item.time = data.time;
	newnode->item.string = (char *)newnode + sizeof(list_t);
	strcpy(newnode->item.string, data.string);
	newnode->next = NULL;
	if (headptr == NULL) {
		headptr = newnode;
	} else {
		tailptr->next = newnode;
	}
	tailptr = newnode;
	return 0;
}

void clearlog(void) {  
	log_t *tmp;
	while (headptr != NULL) {
		tmp = headptr->next;
		headptr = NULL;
		headptr = tmp;	
	}
	tailptr = NULL;
} 

char *getlog(void) {
	char *str = NULL;
	log_t *tmp = headptr;
	int strsize;
	
	strsize = sizeof(char *) + 1;
	while (tmp->next != NULL) {
		strsize += strlen(tmp->data.string);
		tmp = tmp->next;
	}
	
	if((str = (char *)(malloc(strsize))) == NULL) return -1;

	tmp = headptr;
	while (tmp->next != NULL) {
		strcat(str, tmp->data.string);
		tmp = tmp->next;
	}
	return str;		
}
 
int savelog(char *filename) {
   return 0;
}
