int myarray[50000] = {1, 2, 3, 4};

int main(void) {
   myarray[0] = 3;
   return 0;
}
